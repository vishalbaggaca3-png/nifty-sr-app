# NIFTY Support & Resistance Tool

This is a Streamlit app to visualize support and resistance levels of NIFTY 50.

## How to Deploy

1. Upload this repo to GitHub.
2. Go to [Streamlit Cloud](https://streamlit.io/cloud) and create a new app.
3. Select this repo and deploy.
4. The app will be live at your personal Streamlit URL.