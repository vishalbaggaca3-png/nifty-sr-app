import streamlit as st
import yfinance as yf
import matplotlib.pyplot as plt

st.title("📈 NIFTY Support & Resistance Tool")

# Inputs
start_date = st.date_input("Start Date")
end_date = st.date_input("End Date")
window = st.slider("Window for S/R detection", 3, 20, 5)

symbol = "^NSEI"

# Fetch data
data = yf.download(symbol, start=start_date, end=end_date)
data = data[['High','Low','Close']]

# Identify support and resistance
def identify_sr(data, window):
    support = []
    resistance = []
    for i in range(window, len(data)-window):
        local_min = min(data['Low'][i-window:i+window])
        local_max = max(data['High'][i-window:i+window])
        if data['Low'][i] == local_min:
            support.append((i, data['Low'][i]))
        if data['High'][i] == local_max:
            resistance.append((i, data['High'][i]))
    return support, resistance

support, resistance = identify_sr(data, window)

# Plot chart
fig, ax = plt.subplots(figsize=(10,5))
ax.plot(data['Close'], label='NIFTY Close', color='blue')
for s in support:
    ax.hlines(s[1], xmin=s[0]-5, xmax=s[0]+5, colors='green')
for r in resistance:
    ax.hlines(r[1], xmin=r[0]-5, xmax=r[0]+5, colors='red')
ax.set_title("NIFTY Support & Resistance")
ax.legend()
st.pyplot(fig)

# Display key levels
support_prices = sorted(set([s[1] for s in support]))
resistance_prices = sorted(set([r[1] for r in resistance]))
st.subheader("Key Levels")
st.write("Support (green):", support_prices)
st.write("Resistance (red):", resistance_prices)